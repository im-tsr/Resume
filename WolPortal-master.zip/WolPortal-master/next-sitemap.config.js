module.exports = {
  siteUrl: 'https://wolmer.me/',
  generateRobotsTxt: true,
  exclude: ['/api*'],
};
