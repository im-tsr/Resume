module.exports = {
  bracketSpacing: true,
  singleQuote: true,
  semi: true,
  trailingComma: 'all',
  printWidth: 120,
  tabWidth: 2,
  endOfLine: 'auto',
};
